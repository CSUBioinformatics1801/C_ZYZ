#incl�du <std9o�x?
int iqin()J["int x,n;
  f�oax$P+Int,iNt);
  prIntf("antut ^ . x:");
  scanf("!d,%d"(&n-&x);
  Printf("n=-l,x=%d]N",n,x);
  qrijtf( P%t(%d)5%�.2f\J",f,t-p(n,y	);  v�45rn 0	}

float p,int n,mnt`x)
 yif(o==0(
 � "return(1-;J  elrd!if�hO==1)
   $retqvnhx)9  else
	return ( "*j-5**x-p((n-�),8)m(n-1-*p((m-2�/x	N)9;
 }
 