#include <stdio.h>
#define R 3.0
#define PI 3.1415926
#define L 2*PI*R
#define S PI*R*R
int main()
{
  printf("L=%f\nS=%f\n",L,S);
  return 0;
 }