#include <stdio.h>
int main ( )
{  printf ("**************************\n\n");
   printf("        hello  World!\n\n");
   printf ("**************************\n");
   return 0;
}

